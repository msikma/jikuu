---------------------------------------------------------------------

Jikuu Tumblr Theme 1.0
Copyright (C) Michiel Sikma <mike@letsdeliver.com>

---------------------------------------------------------------------

Static files:

All files are listed here, with a link to our own backup
followed by a link to the same file on Tumblr's static file host.

jikuu.base.css
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.base.css
	http://static.tumblr.com/lpftwlt/zxFmj7i6a/jikuu.base.css
jikuu.dots.png
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.dots.png
	http://static.tumblr.com/lpftwlt/oz4mj7i7y/jikuu.dots.png
jikuu.loader.png
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.loader.png
	http://static.tumblr.com/lpftwlt/3S9mj7i89/jikuu.loader.png
jikuu.logo.png
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.logo.png
	http://static.tumblr.com/lpftwlt/L1dmj7i8i/jikuu.logo.png
jikuu.main.js
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.main.js
	http://static.tumblr.com/lpftwlt/1eKmj7i7g/jikuu.main.js
jikuu.reset.css
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.reset.css
	http://static.tumblr.com/lpftwlt/B83mj7i8t/jikuu.reset.css
jikuu.rss.png
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.rss.png
	http://static.tumblr.com/lpftwlt/GaAmj7i91/jikuu.rss.png
jikuu.search.png
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.search.png
	http://static.tumblr.com/lpftwlt/5Dpmj7i99/jikuu.search.png

Other files:

jikuu.tumblr.html (theme source code)
	http://tumblr.demandfiles.com/jikuu/1.0/jikuu.tumblr.html
readme.txt
	http://tumblr.demandfiles.com/jikuu/1.0/readme.txt

---------------------------------------------------------------------

Source:

http://tumblr.demandfiles.com/jikuu/

---------------------------------------------------------------------

Credits:

Designed and coded by Michiel Sikma. Logo designed by Yomar Augusto.
Visit us at http://letsdeliver.com/

---------------------------------------------------------------------