/*
 * Jikuu Tumblr Theme - JS Code
 * Copyright (C) 2013, Michiel Sikma <mike@letsdeliver.com>
 * All Rights Reserved
 * Date: 2013/05/11
 *
 * @author Michiel Sikma
 *
// ==ClosureCompiler==
// @output_file_name jikuu.min.js
// @compilation_level ADVANCED_OPTIMIZATIONS
// @externs_url http://closure-compiler.googlecode.com/svn/trunk/contrib/externs/jquery-1.8.js
// ==/ClosureCompiler==
 *
 */

window["JikuuMain"] = function(overrides)
{
	var self				= this;
	
	var $window;
	var $document;
	
	/* Elements used. */
	var $root;
	
	var $header;
	var $title;
	
	var $form_search;
	var $_fix_toggle_item;
	var fix_scan_interval	= 3000;		// how often the fixed elements are rescanned
	
	var $section_me;
	var $section_main_nav;
	var $section_twitter;
	var $section_contributors;
	var $section_follows;
	
	var $content;
	var $content_sidebar;
	var $content_main;
	
	var $container_posts;
	var $container_nav;
	
	var posts_col_left		= 0;		// height of the left and right
	var posts_col_right		= 0;		// columns in pixels
	var posts_processed		= {};
	
	var $_post, $post;
	var $_menu_item, $menu_item;
	
	var $loader_posts;
	
	var window_scroll_top;				// viewport vertical scroll amount
	var window_height;					// viewport height
	
	/* Default settings. */
	var defaults			= {
		$root				: null,		// the root element in use
		debug				: true,		// console debugging
		inf_scroll			: true,		// whether to use infinite scrolling
		inf_scroll_margin	: 300,		// trigger distance from page bottom
		loader_speed		: 70,		// speed in ms of loader
		loader_size			: 16,		// size in px of loader
		loader_frames		: 5			// amount of frames in loader
	};
	/* Container for instance settings. */
	var settings			= {};
	
	var permit_debug;
	
	/*
	 * Logs messages to the console.
	 */
	self.debug = function(str, vars, func)
	{
		if (permit_debug != true
		||  window.console == null) {
			return;
		}
		
		func = func == null ? "log" : func;
		vars = vars == null ? [] : vars;
		if (vars.constructor.toString().indexOf("Array") == -1) {
			vars = [vars];
		}
		vars.unshift(str);
		console[func].apply(console, vars);
	}
	
	/*
	 * Updates the window scroll amount and height.
	 */
	self.update_window_info = function()
	{
		window_scroll_top = $(window).scrollTop();
		window_height = $(window).height();
	}
	
	/*
	 * Sets the triggers that update the screen.
	 */
	self.init_update_trigger = function()
	{
		$window.bind("scroll resize", function()
		{
			self.update_trigger();
		});
		setInterval(function()
		{
			self.scan_fixed_elements();
		}, fix_scan_interval);
	}
	
	/*
	 * Finds and sets up all elements that are used.
	 */
	self.init_elements = function()
	{
		$window = $(window);
		$document = $(document);
		
		if (settings.$root) {
			$root = settings.$root;
		}
		else {
			$root = $("#root");
			if ($root[0]) {
				self.debug("found #root element %o", [$root[0]]);
			}
			else {
				self.debug("JikuuMain::init_elements(): couldn't find root element", [], "error");
			}
		}
		
		$header = $("#header", $root);
		$title = $("#title", $root);
		
		$form_search = $("#form_search", $root);
		
		$section_me = $("#section_me", $root);
		$section_main_nav = $("#section_main_nav", $root);
		$section_twitter = $("#section_twitter", $root);
		$section_contributors = $("#section_contributors", $root);
		$section_follows = $("#section_follows", $root);
		
		$content = $("#content", $root);
		$content_sidebar = $("#content_sidebar", $root);
		$content_main = $("#content_main", $root);
		
		$container_posts = $("#container_posts", $root);
		$container_nav = $("#container_nav", $root);
		
		$loader_posts = $("#loader_posts", $root);
	}
	
	self.after_images_loaded = function($el, callback)
	{
		var a, z;
		
		/* List the amount of images we have. */
		var $_img = $("img", $el);
		var amount_total = $_img.length;
		var amount_preloaded = 0;
		
		function check_progress()
		{
			if (amount_preloaded >= amount_total) {
				callback.call();
			}
		}
		
		for (a = 0, z = $_img.length; a < z; ++a) {
			$img = $($_img[a]);
			$img.one("load", function()
			{
				amount_preloaded += 1;
				check_progress();
			})
			.each(function()
			{
				if (this.complete || $img.height() > 0) {
					$(this).trigger("load");
				}
			});
		}
	}
	
	/*
	 * Actually initializes the appropriate page layout.
	 */
	self.init_page_layout = function()
	{
		if (window.JikuuSettings.page.type == "index") {
			/* Index pages: check post info and move them to the appropriate column. */
			self.after_images_loaded($container_posts, function()
			{
				self.determine_post_positions();
				self.init_photoset_grids();
			});
		}
		else {
			/* Permalink pages. */
		}
	}

	/*
	 * Finds and initializes posts.
	 */
	self.determine_post_positions = function()
	{
		self.debug("Determining post positions");
		$_post = $("> .post", $container_posts);
		self.debug("Processing %i posts:", [$_post.length]);
		var processed, id, height, pull;
		for (var a = 0, z = $_post.length; a < z; ++a) {
			$post = $($_post[a]);
			id = $post.attr("data-id");
			processed = posts_processed[id];
			if (processed) {
				self.debug("  Post %i is already processed (skipping)", [id]);
				continue;
			}
			height = $post.height();
			$post.removeClass("pull-left");
			$post.removeClass("pull-right");
			if (posts_col_left <= posts_col_right) {
				pull = "pull-left";
				posts_col_left += height;
			}
			else {
				pull = "pull-right";
				posts_col_right += height;
			}
			$post.addClass(pull);
			self.debug("  Post %i has been set to %i", [id, pull]);
			posts_processed[id] = true;
			$post.attr("data-height", height);
		}
	}
	
	/*
	 * Empties out the post positioning cache and rebuilds it from scratch.
	 */
	self.reset_posts = function()
	{
		posts_processed = {};
		posts_col_left = 0;
		posts_col_right = 0;
	}
	
	/*
	 * Finds and lists fixed elements.
	 */
	self.init_fixed_elements = function()
	{
		self.debug("Initializing fixed elements");
		$_fix_toggle_item = $(".fix-toggle-item", $root);
		self.scan_fixed_elements();
	}
	
	self.scan_fixed_elements = function()
	{
		//self.debug("Scanning fixed elements");
		$_fix_toggle_item.each(function(n, fix_toggle_item)
		{
			var $fix_toggle_item = $(fix_toggle_item);
			var $fix_gap = $("> .fix-gap", $fix_toggle_item);
			var $fix_content = $("> .fix-content", $fix_toggle_item);
			var $fix_padding = $("> .fix-padding", $fix_toggle_item);
			var p_top = parseInt($fix_padding.css("padding-top"), 10);
			var p_bottom = parseInt($fix_padding.css("padding-bottom"), 10);
			var height = $fix_content.height();
			//self.debug("Element %o height: %d", [$fix_content[0], height]);
			$fix_gap.height(height+"px");
			var offset = $fix_toggle_item.offset().top;
			var toggled = $fix_toggle_item.hasClass("pmode");
			$.data(fix_toggle_item, "fixinfo_state", toggled);
			$.data(fix_toggle_item, "fixinfo", {
				$el: $fix_toggle_item,
				$ct: $fix_content,
				height: height,
				offset: offset,
				p_top: p_top,
				p_bottom: p_bottom
			});
		});
	}
	
	/*
	 *
	 */
	self.update_menu_items = function()
	{
		var curr_path = window.location.pathname;
		self.debug("JikuuMain::update_menu_items(): Current page: %i", [curr_path], "info");
		$_menu_item = $("ul.nav > li", $section_main_nav);
		$_menu_item.each(function(n, menu_item)
		{
	 		$menu_item = $(menu_item);
	 		var $menu_a = $("> a", $menu_item);
	 		var menu_href = $menu_a.attr("href");
	 		if (menu_href == curr_path) {
	 			/* This is the current item. */
	 			self.debug("Setting menu item %o to active", [menu_item]);
	 			$menu_item.addClass("active");
	 		}
		});
	}
	
	self.init_photoset_grids = function()
	{
		var $photoset_grid, id;
		var gutter = window.JikuuSettings.settings.photoset_grid_gutter;
		for (var a = 0, z = $_post.length; a < z; ++a) {
			$post = $($_post[a]);
			if ($post.hasClass("photoset")) {
				$photoset_grid = $(".photoset-grid", $post);
				id = $photoset_grid.attr("data-id");
				
				$photoset_grid.photosetGrid({
					highresLinks: true,
					rel: id,
					gutter: gutter,
					onComplete: function()
					{
					}
				});
			}
		}
	}
	
	/*
	 * Detaches and reattached fixed elements such as the main navigation.
	 */
	self.update_fixed_elements = function()
	{
		var fix_toggle_item, data, fixed;
		var $el, $ct, height, offset, p_top, p_bottom;
		for (var a = 0, z = $_fix_toggle_item.length; a < z; ++a) {
			fix_toggle_item = $_fix_toggle_item[a];
			data = $.data(fix_toggle_item, "fixinfo");
			fixed = $.data(fix_toggle_item, "fixinfo_state");
			$el = data.$el;
			$ct = data.$ct;
			height = data.height;
			offset = data.offset;
			p_top = data.p_top;
			p_bottom = data.p_bottom;
			if (window_scroll_top > (offset - p_top)) {
				if (fixed == true) {
					continue;
				}
				$el.addClass("pmode");
				$ct.css({paddingTop: p_top+"px", paddingBottom: p_bottom+"px"});
				fixed = true;
			}
			else {
				if (fixed == false) {
					continue;
				}
				$el.removeClass("pmode");
				$ct.css({paddingTop: 0, paddingBottom: 0});
				fixed = false;
			}
			$.data(fix_toggle_item, "fixinfo_state", fixed);
		}
	}
	
	/*
	 * Updates the screen.
	 */
	self.update_trigger = function()
	{
		self.update_window_info();
		self.update_fixed_elements();
	}
	
	/*
	 * Toggles debugging on or off.
	 */
	self["toggle_debug"] = function(aux)
	{
		permit_debug = aux;
	}
	
	self.__init__ = function(overrides)
	{
		/* Override default settings with user-supplied ones. */
		settings = defaults;
		for (var key in overrides) {
			settings[key] = overrides[key];
		}
		self["toggle_debug"](settings.debug);
		self.debug("Jikuu Tumblr Theme v%d.%d", [
			window.JikuuSettings.version.major,
			window.JikuuSettings.version.minor
		], "warn");
		self.debug("© 2013, Michiel Sikma", [], "warn");
		self.debug("JikuuMain::__init__(): initializing new JikuuMain instance", [], "info");
		self.init_elements();
		self.update_menu_items();
		self.init_fixed_elements();
		self.init_update_trigger();
		self.update_trigger();
		self.init_page_layout();
		self.debug("Done initializing instance");
	}
	self.__init__(overrides);
}

$(function()
{
	window.jm = new JikuuMain({
	});
});
$(function()
{
    /* The basics. */
    var $window = $(window);
    var $document = $(document);
    var $root = $("#root");
        
    /* Grab some exported Tumblr theme variables. */
    var settings = window.JikuuSettings;
    
    /* Some other settings, either static or determined by the HTML. */
    settings.use_endless_scrolling = $root.hasClass("endless");
    settings.newpage_margin = 300;  /* Distance for new page load. */
    settings.search_mods = true;    /* Whether to use search modifications. */
    settings.loader_speed = 70;     /* Speed in ms for animated loader image. */
    settings.loader_size = 16;      /* Size in pixels of loader image. */
    settings.loader_frames = 5;     /* Amount of frames in loader image. */
    
    /* Prefix to use for AJAX calls. */
    var url_prefix = window.location.pathname;
    /* Add trailing slash, except if we're on the root. */
    if (url_prefix != "/") {
        url_prefix += "/";
    }
    var $sidebar = $(".subwrapper.sidebar", $root);
    
    if (settings.search_mods) {
        /*
         * Some minor modifications to the search form.
         * When initiating a search, we'll replace the magnifying glass
         * with a loader image. This loader image is animated by changing
         * its background-position.
         */
        var $search = $(".section.search", $sidebar);
        var $search_header = $("h3", $search);
        search_label = $search_header.text();
        var $search_form = $("form", $search);
        var $search_icon = $(".sub", $search_form);
        $search_form.submit(function()
        {
            $search.addClass("loading");
            /* Still execute the search normally. */
            return true;
        });
        /* The timer performing the background-position modification. */
        var search_bg_pos = 0;
        var search_bg_frame = 0;
        var search_timer = setInterval(function()
        {
            search_bg_frame += 1;
            search_bg_pos -= settings.loader_size;
            if (search_bg_frame > settings.loader_frames) {
                search_bg_frame = 0;
                search_bg_pos = 0;
            }
            $search_icon.css({backgroundPosition: search_bg_pos+"px 0"});
        }, settings.loader_speed);
    }
    
    /* First, check if we can even navigate on this page. */
    var can_scroll = $(".subwrapper.nav", $root).length > 0;
    if (settings.use_endless_scrolling && can_scroll) {
        var is_loading = false;
        var error = false;
        var end = false;
        var page_n = 1;
        
        /* First, hide the regular navigation. */
        var $nav = $(".subwrapper.nav", $root);
        var $jumppag = $(".jumppag", $nav);
        $jumppag.hide();
        
        /* Set up the loader. */
        var $loader = $(".loader", $nav);
        var $loader_error = $(".error", $loader);
        var $loader_done = $(".done", $loader);
        var $loader_icon = $(".inner", $loader);
        var loader_bg_pos = 0;
        var loader_bg_frame = 0;
        var loader_timer = setInterval(function()
        {
            loader_bg_frame += 1;
            loader_bg_pos -= settings.loader_size;
            if (loader_bg_frame > settings.loader_frames) {
                loader_bg_frame = 0;
                loader_bg_pos = 0;
            }
            if (end == false) {
                $loader_icon.css({backgroundPosition: loader_bg_pos+"px 0"});
            }
        }, settings.loader_speed);
        
        /* Create a temporary container. */
        var $tmp_container = $("<div id=\"tmp_container\"></div>").appendTo($root);
        var $post_container = $("#post_container");
        
        /* As soon as the user scrolls within range, load the next page. */
        $document.bind("scroll", function()
        {
            var scroll_position = $window.scrollTop();
            var document_height = $document.height();
            var viewport_height = $window.height();
            if (scroll_position - (document_height - viewport_height) >= -settings.newpage_margin && is_loading == false && error == false && end == false) {
                page_n += 1;
                is_loading = true;
                $loader.css({visibility: "visible"});
                $loader.removeClass("error");
                $loader_error.text("");
                var url = url_prefix+"page/"+page_n+" #post_container > .post";
                $tmp_container.load(url, function(response, status, xhr)
                {
                    is_loading = false;
                    $loader.css({visibility: "hidden"});
                    if (status == "error") {
                        $loader.addClass("error");
                        $loader_error.text("Couldn't load next page.");
                        error = true;
                    }
                    $posts = $(".post", this);
                    if ($posts.length == 0) {
                        /* We've reached the end. */
                        end = true;
                        $loader.css({visibility: "visible"});
                        $loader_done.show();
                    }
                    
                    $posts.appendTo($post_container);
                    $tmp_container.empty();
                    
                    /*
                     * Now execute all scripts in the posts HTML.
                     * We use a bit of a hack for this because jQuery
                     * strips out the <script> tags as soon as you make a
                     * more specific jQuery object
                     * (e.g. $(response).find("#post_container") won't work).
                     *
                     * So instead we match the entire posts section manually
                     * using a regex and then iterate over the script tags.
                     */
                    var posts_html = response.match(/<\!-- jikuu_post_container start -->(.|\s)*?<\!-- jikuu_post_container end -->/mi);
                    $(posts_html[0]).filter("script").each(function()
                    {
                        /* Evaluate every script in the global namespace. */
                        $.globalEval(this.text || this.textContent || this.innerHTML || "");
                    });
                    
                    /*
                     * In case we're using Google Analytics,
                     * report this page load.
                     */
                    if (typeof window._gaq != 'undefined') {
                        _gaq.push(['_trackPageview', url]);
                    }
                });
            }
        });
    }
});
